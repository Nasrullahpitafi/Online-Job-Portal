//
//  Constant.swift
//  Rozeefyp
//
//  Created by Asjd on 24/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
struct Constant {
    
    static var user : [Signup] = []

    
}
