//
//  Appliersdata.swift
//  Rozeefyp
//
//  Created by Asjd on 30/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
import SVProgressHUD
class AppliersData: Codable {

    
    var id : Int = 0
    var jobid : Int = 0
    var companyid : Int = 0
    var jobseekerid : Int = 0
    var status : String? = ""
    var quizscore : String? = ""
}

class AppliersDataManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    
    
    public func searchById(id : Int)->[AppliersData]{
        var jobsdata : [AppliersData] = []
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "applierdata", actionName: "searchApplierById?id=\(id)")
        print("my searching id = \(id)")
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                print(jobsdata[0].status)
                Message = result.ResponseMessage
                return jobsdata
            }
            
            //data is ok
            jobsdata = try! decoder.decode([AppliersData].self, from: data)
            print(jobsdata[0].status
            )
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        print(jobsdata[0].status)
        return jobsdata
    }
    
    
    
    
    
    public func updatestatus(newstatus:AppliersData)->Bool{
        
        
        let data = try! encoder.encode(newstatus)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "applierdata", actionName: "updatestatus", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
    }
    
}

