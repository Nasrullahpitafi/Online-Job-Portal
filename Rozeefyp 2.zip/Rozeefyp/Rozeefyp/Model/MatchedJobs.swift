import Foundation



class MatchedJobs : Codable{
    var id : Int = 0
    var jobtitle : String? = ""
    var jobtype : String? = ""
    var salary : String? = ""
    var skills : String? = ""
    var careerlevel : String? = ""
    var city : String? = ""
    var education : String? = ""
    var gender : String? = ""
    var currentdate : String? = ""
    var lastdate : String? = ""
    var description : String? = ""
    var companyname : String? = ""
    var experience : String? = ""
    var image : String? = ""
    var companyid : Int? = 0
    
    
}

class MatchedJobsManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    public func matchedjobs(skill:String )->[MatchedJobs]{
        var matcheddata : [MatchedJobs] = []
        
        let result = apiWrapper.getMethodCall(controllerName: "jobs", actionName: "matchedjobs?&skill=\(skill)"  )
        if result.ResponseCode == 200{
            //ok
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return matcheddata
            }
            
            //data is ok
            matcheddata = try! decoder.decode([MatchedJobs].self, from: data)
            print("i am here")
            print(matcheddata.first?.id)
            print(matcheddata.first?.jobtitle)
            
        }
        else{
            Message = result.ResponseMessage
        }
        return matcheddata
        
        
        
        
        
    }
    
    
}
