//
//  AppliedData.swift
//  Rozeefyp
//
//  Created by Asjd on 26/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
import SVProgressHUD
class AppliedData: Codable {
    var id : Int = 0
    var companyid : Int = 0
    var jobseekerid : Int = 0
    var jobid : Int = 0
    var status : String? = ""
    var quizscore : String? = ""
}
class AppliedDataManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    public func postapplydata(newapply:AppliedData)->Bool{
        
        
        let data = try! encoder.encode(newapply)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "ApplierData", actionName: "applydata", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
    }
    public func checkapply(jobseekerid:Int,jobid:Int )->[AppliedData]{
        var logindata : [AppliedData] = []
        
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "ApplierData", actionName: "checkapply?jobseekerid=\(jobseekerid)&jobid=\(jobid)"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return logindata
            }
            
            //data is ok
            logindata = try! decoder.decode([AppliedData].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return logindata
    }
    
    
}

