import Foundation


class JobsByCompany : Codable{
    var id : Int = 0
    var jobtitle : String? = ""
    var jobtype : String? = ""
    var salary : String? = ""
    var skills : String? = ""
    var careerlevel : String? = ""
    var city : String? = ""
    var education : String? = ""
    var gender : String? = ""
    var currentdate : String? = ""
    var lastdate : String? = ""
    var description : String? = ""
    var companyname : String? = ""
    var experience : String? = ""
    var image : String? = ""
    var companyid : Int? = 0
    
    
    
}

class JobsByCompanyManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    public func jobsbycompany(companyid:Int )->JobsByCompany{
        var viewjobs : [JobsByCompany] = []
        
        let result = apiWrapper.getMethodCall(controllerName: "Jobs", actionName: "jobsbycompany?companyid=\(companyid)"  )
        if result.ResponseCode == 200{
            //ok
            
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return viewjobs
            }
            
            //data is ok
            viewjobs = try! decoder.decode([JobsByCompany].self, from: data)
            
        }
        else{
            Message = result.ResponseMessage
        }
        return viewjobs
        
    }
    
    
}

