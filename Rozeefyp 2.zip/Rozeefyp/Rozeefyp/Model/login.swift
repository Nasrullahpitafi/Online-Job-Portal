//
//  login.swift
//  Rozeefyp
//
//  Created by Asjd on 14/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
import SVProgressHUD

class Signup : Codable{
    var id : Int = 0
    var username : String? = ""
    var email : String? = ""
    var password : String? = ""
    var city : String? = ""
    var expectedsalary : String? = ""
    var education : String? = ""
    var phoneno : String? = ""
    var address : String? = ""
    var jobtitleinterested : String? = ""
    var skills : String? = ""
    var usertype : String? = ""
    var image : String? = ""

}

class SignupManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""

    public func jobseekeerignup(newlogin:Signup)->Bool{
        
        
        let data = try! encoder.encode(newlogin)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "login", actionName: "jobseekersignup", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
}
    public func updatestatus(newprofile:Signup)->Bool{
        
        
        let data = try! encoder.encode(newprofile)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "login", actionName: "updateprofile", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
    }
    
    
    public func login(email:String,password:String )->[Signup]{
        var logindata : [Signup] = []

        SVProgressHUD.show()
       let result = apiWrapper.getMethodCall(controllerName: "login", actionName: "alllogins?email=\(email)&password=\(password)"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return logindata
            }
            
            //data is ok
            logindata = try! decoder.decode([Signup].self, from: data)
        
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return logindata

        
        
        
        
    }
    
}
