import Foundation
import SVProgressHUD


class Jobs : Codable{
    var id : Int = 0
    var jobtitle : String? = ""
    var jobtype : String? = ""
    var salary : String? = ""
    var skills : String? = ""
    var careerlevel : String? = ""
    var city : String? = ""
    var education : String? = ""
    var gender : String? = ""
    var currentdate : String? = ""
    var lastdate : String? = ""
    var description : String? = ""
    var companyname : String? = ""
    var experience : String? = ""
    var image : String? = ""
    var companyid : Int? = 0



}

class JobsManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    public func alljobs()->[Jobs]{
        var jobsdata : [Jobs] = []
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "Jobs", actionName: "alljobs")
        
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return jobsdata
            }
            
            //data is ok
            jobsdata = try! decoder.decode([Jobs].self, from: data)
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return jobsdata
}
    
 /*   public func myRelatedJobs(jobTitle:String, skill:String)->[Jobs]{
        var jobsdata : [Jobs] = []
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "Jobs", actionName: "matchedjobs?jobTitle=\(jobTitle)&skill=\(skill)")
        
        
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return jobsdata
            }
            
            //data is ok
            jobsdata = try! decoder.decode([Jobs].self, from: data)
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        print("here we wre")
        print(jobsdata.first?.jobtitle)
        return jobsdata
    }*/
    public func postjob(newjob:Jobs)->Bool{
        
        
        let data = try! encoder.encode(newjob)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "Jobs", actionName: "postjob", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
    }
    
    public func jobsbycompany(companyid:Int )->[Jobs]{
        var viewjobs : [Jobs] = []
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "Jobs", actionName: "jobsbycompany?companyid=\(companyid)"  )
        if result.ResponseCode == 200{
            //ok
            
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return viewjobs
            }
            SVProgressHUD.dismiss()
            //data is ok
            viewjobs = try! decoder.decode([Jobs].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return viewjobs
        
    }
    

}
