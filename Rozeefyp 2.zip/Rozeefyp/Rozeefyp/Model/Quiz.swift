//
//  Quiz.swift
//  Rozeefyp
//
//  Created by Asjd on 01/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
import SVProgressHUD

class Quiz : Codable{
    var id : Int = 0
    var question : String? = ""
    var optiona : String? = ""
    var optionb : String? = ""
    var optionc : String? = ""
    var optiond : String? = ""
    var answer : String? = ""
    var jobid : Int = 0
    var quizid : Int = 0
}
class QuizManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    public func postquiz(newquiz:Quiz)->Bool{
        
        
        let data = try! encoder.encode(newquiz)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "Quiz", actionName: "postaddquiz", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            print("i am here true")
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            print("i am here false")

            return false
        }
        
}
    public func getquiz(jobid:Int)->[Quiz]{
        var quizdata : [Quiz] = []
        
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "Quiz", actionName: "getjobquiz?jobid=\(jobid)"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return quizdata
            }
            
            //data is ok
            quizdata = try! decoder.decode([Quiz].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return quizdata
    }
}
