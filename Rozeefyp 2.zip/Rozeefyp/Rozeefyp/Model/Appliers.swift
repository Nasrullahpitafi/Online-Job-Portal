//
//  Appliers.swift
//  Rozeefyp
//
//  Created by Asjd on 08/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
import SVProgressHUD

class Appliers: Codable {
    var username : String!
    var jobtitle : String!
    var status : String!
    var quizscore : String!
    
    
    var id : Int!
    var jobid : Int!
    var companyid : Int!
    var jobseekerid : Int!
    
    
}
class AppliersManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    
    public func appliers(company:Int)->[Appliers]{
        var appliers : [Appliers] = []
        
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "applierdata", actionName: "appliedjobscompany?company=\(company)"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return appliers
            }
            
            //data is ok
            appliers = try! decoder.decode([Appliers].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return appliers
        
}
    public func searchById(id : Int)->[Appliers]{
        var jobsdata : [Appliers] = []
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "applierdata", actionName: "searchApplierById?id=\(id)")
        print("my searching id = \(id)")
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                print(jobsdata[0].jobtitle)
                Message = result.ResponseMessage
                return jobsdata
            }
            
            //data is ok
            jobsdata = try! decoder.decode([Appliers].self, from: data)
            print(jobsdata[0].jobtitle)
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        print(jobsdata[0].jobtitle)
        return jobsdata
    }
    
    
    
    
    
    public func updatestatus(newstatus:Appliers)->Bool{
        
        
        let data = try! encoder.encode(newstatus)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "applierdata", actionName: "updatestatus", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
    }
    
}
