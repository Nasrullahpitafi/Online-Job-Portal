import Foundation
import SVProgressHUD

class FavouriteJobs: Codable {
    var username : String!
    var city : String!
    var phoneno : String!
    var image : String!
    var jobid : Int!
    var jobseekerid : Int!
    var companyid : Int!
    var id : Int!
    var jobtitle : String? = ""
    var jobtype : String? = ""
    var salary : String? = ""
    var skills : String? = ""
    var careerlevel : String? = ""
    var education : String? = ""
    var gender : String? = ""
    var currentdate : String? = ""
    var lastdate : String? = ""
    var description : String? = ""
    var companyname : String? = ""
    var experience : String? = ""




}
class FavouriteJobsManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    
    public func allcompanies()->[FavouriteJobs]{
        var applieddata : [FavouriteJobs] = []
        
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "FavouriteJobs", actionName: "allcompanies"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return applieddata
            }
            
            //data is ok
            applieddata = try! decoder.decode([FavouriteJobs].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return applieddata
        
    }
    public func favouritedata(newdata:FavouriteJobs)->Bool{
        
        
        let data = try! encoder.encode(newdata)
        SVProgressHUD.show()
        let result = apiWrapper.postMethodCall(controllerName: "FavouriteJobs", actionName: "favouritedata", httpBody: data)
        
        if result.ResponseCode == 200 {
            SVProgressHUD.dismiss()
            return true
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
            return false
        }
        
    }
    
    public func favouritejobs(jobseeker : Int)->[FavouriteJobs]{
        var  favouritejobsdata : [FavouriteJobs] = []
        
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "FavouriteJobs", actionName: "favourite?jobseeker=\(jobseeker)"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return favouritejobsdata
            }
            
            //data is ok
            favouritejobsdata = try! decoder.decode([FavouriteJobs].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return favouritejobsdata
        
    }
    
}

