//
//  AppliedJobs.swift
//  Rozeefyp
//
//  Created by Asjd on 03/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import Foundation
import SVProgressHUD

class AppliedJobs: Codable {
    var username : String!
    var jobtitle : String!
    var companyname : String!
    var lastdate : String!
    var city : String!
    var status : String!
    var jobid : Int = 0
    var id : Int = 0
    var companyid : Int = 0
}
class AppliedJobsManager{
    
    var apiWrapper = APIWrapper()
    var decoder = JSONDecoder()
    var encoder = JSONEncoder()
    var Message = ""
    
    
    public func appliedjobs(jobseeker:Int)->[AppliedJobs]{
        var applieddata : [AppliedJobs] = []
        
        SVProgressHUD.show()
        let result = apiWrapper.getMethodCall(controllerName: "applierdata", actionName: "appliedjobsjobseeker?jobseeker=\(jobseeker)"  )
        if result.ResponseCode == 200{
            //ok
            SVProgressHUD.dismiss()
            guard let data = result.ResponseData else {
                Message = result.ResponseMessage
                return applieddata
            }
            
            //data is ok
            applieddata = try! decoder.decode([AppliedJobs].self, from: data)
            
        }
        else{
            SVProgressHUD.dismiss()
            Message = result.ResponseMessage
        }
        return applieddata
        
    }
}
