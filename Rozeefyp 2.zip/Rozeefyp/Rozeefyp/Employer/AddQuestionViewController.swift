//
//  AddQuestionViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 07/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AddQuestionViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    
    
    @IBOutlet weak var questionFiled: UITextField!
    
    
    @IBOutlet weak var optionAField: UITextField!
    
    @IBOutlet weak var optionBField: UITextField!
    
    @IBOutlet weak var optionCField: UITextField!
    
    @IBOutlet weak var optionDField: UITextField!
    
    
    @IBOutlet weak var answerField: UITextField!
    
    var id : Int?
    
    var correctanswerPicker = UIPickerView()
    var correctanswer = ["A","B","C","D"]
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Addd Question"
        
        answerField.inputView = correctanswerPicker
        answerField.placeholder = "Select Correct Answer"
        
        
        correctanswerPicker.delegate = self
        correctanswerPicker.dataSource = self
        
        
        
    }
    

    @IBAction func AddQuizPressed(_ sender: Any) {
        let data = Quiz ()
          data.question = questionFiled.text
          data.optiona = optionAField.text
          data.optionb = optionBField.text
          data.optionc = optionCField.text
          data.optiond = optionDField.text
          data.answer =    answerField.text
        data.jobid = id! ?? 0
        //  data.quizid = 4
        
        let qm = QuizManager()
        let ans = qm.postquiz(newquiz: data)
        if ans == true {
            navigationController?.popViewController(animated: true)
        }
        else{
            print(qm.Message)
        }
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return correctanswer.count

    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return correctanswer[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        answerField.text = correctanswer[row]
        
        answerField.resignFirstResponder()
        
    }
    
    
}
