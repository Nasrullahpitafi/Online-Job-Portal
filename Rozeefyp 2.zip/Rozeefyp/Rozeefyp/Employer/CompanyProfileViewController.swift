//
//  CompanyProfileViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 24/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class CompanyProfileViewController: UIViewController {

    @IBOutlet weak var companyProfile: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var phoneLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    var imagedata :String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Company Profile"
        
        nameLbl.text = Constant.user.first?.username
        phoneLbl.text = Constant.user.first?.phoneno
        cityLbl.text = Constant.user.first?.city
        
        imagedata = Constant.user.first?.image ?? ""
        if imagedata.count > 0 {
            companyProfile.image = convertBase64ToImage(imagedata)
        }
        
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return (decodedimage!)
    }


}
