//
//  EmployerSignupViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 15/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class EmployerSignupViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource {
    
    
    @IBOutlet weak var companynameField: UITextField!
    
    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var addressField: UITextField!
    
    @IBOutlet weak var cityField: UITextField!
    
    @IBOutlet weak var phonenoField: UITextField!
    
    @IBOutlet weak var companyimage: UIImageView!
    
    
    var strBase64:String?
    var cities =  ["Rawalpindi","Islamabad","Lahore","Multan","Karachi","Faisalabad","DG Khan","Jampur"]
    var citypickerview = UIPickerView()


    override func viewDidLoad() {
        super.viewDidLoad()
        title =  "SignUp"
        
        cityField.inputView = citypickerview
        cityField.placeholder = "Select Your City"
        
        
        citypickerview.delegate = self
        citypickerview.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signupPressed(_ sender: Any) {
        let data = Signup()
        data.usertype = "Employer"
        data.username = companynameField.text!
        data.password = passwordField.text!
        data.email = emailField.text!
        data.address = addressField.text!
        data.phoneno = phonenoField.text!
        data.image = strBase64
        data.city = cityField.text!
        let  sm = SignupManager()
        
        let ans = sm.jobseekeerignup(newlogin: data)
        
        if ans == true {
            navigationController?.popViewController(animated: true)
        }
        else{
            print(sm.Message)
        }
    }
    @IBAction func uploadprofilePressed(_ sender: Any) {
        let mypickercontroller = UIImagePickerController()
        mypickercontroller.delegate = self
        mypickercontroller.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(mypickercontroller, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        let   resizedImage = image?.resized(toWidth: 100)
        let  base64string = convertImageToBase64(resizedImage!)
        companyimage.image = resizedImage
        companyimage.backgroundColor = UIColor.clear
        
        self.dismiss(animated: true, completion: nil)
        
    }
    func convertImageToBase64(_ image: UIImage) -> String {
        let imageData:NSData? =  image.pngData() as NSData?
        
        strBase64 = imageData?.base64EncodedString(options: .lineLength64Characters)
        return strBase64 ?? ""
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return decodedimage!
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cities.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return cities[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        cityField.text = cities[row]
        cityField.resignFirstResponder()
    }
    
    
    
}
