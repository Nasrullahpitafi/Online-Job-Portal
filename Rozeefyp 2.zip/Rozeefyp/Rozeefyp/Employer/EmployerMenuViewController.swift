//
//  EmployerMenuViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 15/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class EmployerMenuViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Employer Menu"

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func viewjobsPressed(_ sender: Any) {
        
        let controller:ViewJobsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewJobsViewController") as! ViewJobsViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
    
    
    @IBAction func applierPressed(_ sender: Any) {
        
        let controller:AppliersDataViewController = self.storyboard?.instantiateViewController(withIdentifier: "AppliersDataViewController") as! AppliersDataViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
    
   
    @IBAction func companyprofilePressed(_ sender: Any) {
        let controller:CompanyProfileViewController = self.storyboard?.instantiateViewController(withIdentifier: "CompanyProfileViewController") as! CompanyProfileViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    @IBAction func postjobPressed(_ sender: Any) {
        let controller:PostJobViewController = self.storyboard?.instantiateViewController(withIdentifier: "PostJobViewController") as! PostJobViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }

    

}
