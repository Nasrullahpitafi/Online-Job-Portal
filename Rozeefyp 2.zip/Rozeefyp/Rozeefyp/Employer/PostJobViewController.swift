//
//  PostJobViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 15/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class PostJobViewController: UIViewController,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate {

    @IBOutlet weak var jobtitleField: UITextField!
    
    @IBOutlet weak var jobtypeField: UITextField!
    
    @IBOutlet weak var skillsField: UITextField!
    
    @IBOutlet weak var salaryField: UITextField!
    
    @IBOutlet weak var lastdateField: UITextField!
    @IBOutlet weak var experienceField: UITextField!
    @IBOutlet weak var genderField: UITextField!
    @IBOutlet weak var educationField: UITextField!
    @IBOutlet weak var descriptionField: UITextField!
    
    
    var currntdate :Date?
    var mydate : String?
    
    
    
    var educations = ["Bachelors","Masters","Doctorate","Diploma","Short Course","Matriculation/O-Level","Intermediate/A-Level","none"]
    var salaries = ["5000-10,000","10,000-20,000","20,000-30,000","30,000-40,000","40,000-50,000","50,000-60,000","60,000+"]
    var jobtype = ["Intern","Full Time"]
    var gender = ["Male","Female","Not Preference"]
    var experience = ["1 Year","2 Year","3 Year","4 Year","5 Year","6 Year","no experience required"]
    
    var educationpickerview = UIPickerView()
    var salraypickerview = UIPickerView()
    var jobtypepicker = UIPickerView()
    var genderpicker = UIPickerView()
    var experiencepicker = UIPickerView()
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Post A Job"
        lastdateField.delegate = self
        self.opendatePicker()
        self.getcurrentdate()
        
        
        educationField.inputView = educationpickerview
        educationField.placeholder = "Select Education"
        salaryField.inputView = salraypickerview
        salaryField.placeholder = "Select  Salary"
        jobtypeField.inputView = jobtypepicker
        jobtypeField.placeholder = "Select Job Type"
        genderField.inputView = genderpicker
        genderField.placeholder = "Select Gender"
        
        experienceField.inputView = experiencepicker
        experienceField.placeholder = "Select Experience"
        
        educationpickerview.delegate = self
        educationpickerview.dataSource = self
        salraypickerview.delegate = self
        salraypickerview.dataSource = self
        genderpicker.delegate = self
        genderpicker.dataSource = self
        jobtypepicker.delegate = self
        jobtypepicker.dataSource = self
        experiencepicker.delegate = self
        experiencepicker.dataSource = self
        
        educationpickerview.tag = 1
        salraypickerview.tag = 2
        jobtypepicker.tag = 3
        genderpicker.tag = 4
        experiencepicker.tag = 5
        

    }
    
    @IBAction func postjobPressed(_ sender: Any) {
        let data  = Jobs()
        data.jobtitle = jobtitleField.text!
        data.jobtype = jobtypeField.text!
        data.skills = skillsField.text!
        data.salary = salaryField.text!
        data.experience = experienceField.text!
        data.education = educationField.text!
        data.gender = genderField.text!
        data.description = descriptionField.text!
        data.currentdate = mydate!
        data.lastdate = lastdateField.text!
        data.companyname = Constant.user.first?.username
        data.city = Constant.user.first?.city
        data.image = Constant.user.first?.image
        data.companyid = Constant.user.first?.id 
        
        let jm = JobsManager()
        let ans = jm.postjob(newjob: data)
        
        if ans == true {
            navigationController?.popViewController(animated: true)
        }
        else{
            print(jm.Message)
        }
        
        
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.opendatePicker()
    }
    func getcurrentdate(){
        currntdate = Date()
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd"
        mydate = df.string(from: Date())
        print(mydate!)
        
    }
    func opendatePicker()
    {
        let datepicker = UIDatePicker()
        datepicker.datePickerMode = .date
        lastdateField.inputView = datepicker
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 41))
        let cancelbtn = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:  #selector(self.cancelbtnclick))
        let donebtn = UIBarButtonItem(title: "Done", style: .done, target: self, action:  #selector(self.donebtnclick))
        let flexiblebtn = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([cancelbtn,donebtn,flexiblebtn], animated: true)
        lastdateField.inputAccessoryView = toolbar
        
    }
    @objc func cancelbtnclick(){
        
        lastdateField.resignFirstResponder()
    }
    @objc func donebtnclick(){
        if let datepicker = lastdateField.inputView as?   UIDatePicker{
            let dateformat = DateFormatter()
            dateformat.dateStyle = .medium
            lastdateField.text = dateformat.string(from: datepicker.date)
            print (datepicker.date)
        }
        lastdateField.resignFirstResponder()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == salraypickerview{
            return salaries.count
        }
        else if pickerView == educationpickerview {
            return educations.count
        }
        else if pickerView == jobtypepicker{
            return jobtype.count
        }
        else if pickerView == genderpicker{
            return gender.count
        }
        else if pickerView == experiencepicker{
            return experience.count
        }
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView == educationpickerview{
            return educations[row]
        }
        else if pickerView == salraypickerview{
            return salaries[row]
        }
        else if pickerView == genderpicker{
            return gender[row]
        }
        else if pickerView == jobtypepicker{
            return jobtype[row]
        }
        else if pickerView == experiencepicker{
            return experience[row]
        }
        
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == educationpickerview{
            educationField.text = educations[row]
            educationField.resignFirstResponder()
        }
        else if pickerView == salraypickerview{
            salaryField.text = salaries[row]
            salaryField.resignFirstResponder()
        }
        else if pickerView == jobtypepicker{
            jobtypeField.text = jobtype[row]
            jobtypeField.resignFirstResponder()
        }
        else if pickerView == genderpicker{
            genderField.text = gender[row]
            genderField.resignFirstResponder()
        }
        else if pickerView == experiencepicker{
            experienceField.text = experience[row]
            experienceField.resignFirstResponder()
        }
        
        
        
    }
    
    
    
}
