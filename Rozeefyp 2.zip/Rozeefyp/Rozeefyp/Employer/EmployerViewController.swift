//
//  EmployerViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 15/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class EmployerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    



}
