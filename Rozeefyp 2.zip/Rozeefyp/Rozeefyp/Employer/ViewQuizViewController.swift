//
//  ViewQuizViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 01/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class ViewQuizViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var addQuestionBtn: UIButton!
    
    var jobid : Int?
    
    var qm = QuizManager()
    var data : [Quiz] = []
    
    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        title = "View Quiz"

        data = qm.getquiz(jobid:jobid!)
        self.tableview.reloadData()
        print(jobid)
        print(data.first?.question!)
        // Do any additional setup after loading the view.
    }
    @IBAction func AddQuestionPressed(_ sender: Any) {
        
        let controller:AddQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AddQuestionViewController") as! AddQuestionViewController
        controller.id = jobid
        self.navigationController?.pushViewController(controller, animated: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "viewquizcell") as! ViewQiuzTableViewCell
        let quizdata = data[indexPath.row]
        print(quizdata.optiona)
        cell.optionALbl.text! = quizdata.optiona!
        cell.optionBLbl.text! = quizdata.optionb!
        cell.optionCLbl.text! = quizdata.optionc!
        cell.optionDLbl.text! = quizdata.optiond!
        cell.questionLbl.text! = quizdata.question!
        cell.answerLbl.text = quizdata.answer!
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }

}
