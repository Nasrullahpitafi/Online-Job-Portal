//
//  AppliersDataViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 08/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AppliersDataViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    
    var am = AppliersManager()
    var data : [Appliers] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Appliers"
       data = am.appliers(company: (Constant.user.first?.id)!)
        
        
       


    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "applierscell") as! AppliersTableViewCell
        let jobsdata = data[indexPath.row]
        cell.jobtitleLabel.text! = jobsdata.jobtitle!
        cell.usernameLabel.text! = jobsdata.username!
        cell.statusid = jobsdata.id
        
        if jobsdata.quizscore.count > 0 {
        cell.quizscore.text! = "Quiz Score \(jobsdata.quizscore!)"
        }else{
            if jobsdata.status == "Shortlisted"{
                cell.quizscore.text = "Quiz Not Attempted Yet"
                cell.quizscore.textColor = .red
            } else{
                cell.quizscore.isHidden = true
            }
        }
        
        return cell
        
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }

}
