//
//  ViewJobsViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 01/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class ViewJobsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    
    var jm = JobsManager()
    var jobsdata : [Jobs] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        jobsdata = jm.jobsbycompany(companyid: Constant.user.first?.id ?? 0)
        print (jobsdata.first?.id)

        title = "View Jobs "

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jobsdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "jobsbycomapnycell") as! JobsByCompnayTableViewCell
        let data = jobsdata[indexPath.row]
        cell.jobtitleLbl.text = data.jobtitle
        cell.descLbl.text = data.description//
        cell.lastdateLbl.text = data.lastdate?.components(separatedBy: "T").first ?? ""
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.date(from:data.lastdate?.components(separatedBy: "T").first ?? "")
        
        cell.ViewQuiz.tag = indexPath.row

        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 240
    }
    
    
    
    @IBAction func ViewQuizPressed(_ sender: UIButton) {
        
        let controller:ViewQuizViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewQuizViewController") as! ViewQuizViewController
        controller.jobid = jobsdata[sender.tag].id
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
}
