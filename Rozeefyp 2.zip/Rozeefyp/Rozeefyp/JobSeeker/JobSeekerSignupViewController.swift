//
//  JobSeekerSignupViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 14/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class JobSeekerSignupViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIPickerViewDataSource,UIPickerViewDelegate {
   
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var education: UITextField!
    @IBOutlet weak var salary: UITextField!
    
    @IBOutlet weak var city: UITextField!
    
    @IBOutlet weak var phoneno: UITextField!
    
    @IBOutlet weak var skills: UITextField!
    
    
    @IBOutlet weak var address: UITextField!
    
    @IBOutlet weak var uploadprofile: UIButton!
    
    
    @IBOutlet weak var userimage: UIImageView!
    
    @IBOutlet weak var confirmpassField: UITextField!
    
    var strBase64:String?
    

    var cities =  ["Rawalpindi","Islamabad","Lahore","Multan","Karachi","Faisalabad","DG Khan","Jampur"]
    var educations = ["Bachelors","Masters","Doctorate","Diploma","Short Course","Matriculation/O-Level","Intermediate/A-Level","none"]
    var salaries = ["5000-10,000","10,000-20,000","20,000-30,000","30,000-40,000","40,000-50,000","50,000-60,000","60,000+"]
    var citypickerview = UIPickerView()
    var educationpickerview = UIPickerView()
    var salraypickerview = UIPickerView()


    override func viewDidLoad() {
        super.viewDidLoad()
        title = "SignUp"
        
        
        city.inputView = citypickerview
        city.placeholder = "Select Your City"
        education.inputView = educationpickerview
        education.placeholder = "Select Your Education"
        salary.inputView = salraypickerview
        salary.placeholder = "Select Your Expected Salary"
        
        
        citypickerview.delegate = self
        citypickerview.dataSource = self
        
        educationpickerview.delegate = self
        educationpickerview.dataSource = self
        
        salraypickerview.delegate = self
        salraypickerview.dataSource = self
        
        citypickerview.tag = 1
        salraypickerview.tag = 2
        educationpickerview.tag = 3

        // Do any additional setup after loading the view.
    }
   
    
    @IBAction func signupPressed(_ sender: Any) {
        let data = Signup()
        if password.text != confirmpassField.text{
        let alert = UIAlertController(title: "Attention", message: "Confirm Your Password", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .destructive, handler: nil)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
        }
        
        data.username = name.text!
        data.email = email.text!
        data.password = password.text!
        data.education = education.text!
        data.city = city.text!
        data.address = address.text!
        data.skills = skills.text!
        data.usertype = "Jobseeker"
        data.image = strBase64
        data.phoneno = phoneno.text!
        data.expectedsalary = salary.text!
        
        let  sm = SignupManager()
        
        let ans = sm.jobseekeerignup(newlogin: data)
        
        if ans == true {
            navigationController?.popViewController(animated: true)
        }
        else{
            print(sm.Message)
        }
    }
    
    @IBAction func uploadprofile(_ sender: Any) {
        let mypickercontroller = UIImagePickerController()
        mypickercontroller.delegate = self
        mypickercontroller.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(mypickercontroller, animated: true, completion: nil)

    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        let   resizedImage = image?.resized(toWidth: 100)
        let  base64string = convertImageToBase64(resizedImage!)
        userimage.image = resizedImage
        userimage.backgroundColor = UIColor.clear
        
        self.dismiss(animated: true, completion: nil)
        
    }
    func convertImageToBase64(_ image: UIImage) -> String {
        let imageData:NSData? =  image.pngData() as NSData?
        
        strBase64 = imageData?.base64EncodedString(options: .lineLength64Characters)
        return strBase64 ?? ""
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == citypickerview{
            return cities.count
        }
        else if pickerView == salraypickerview {
            return salaries.count
        }
        else if pickerView == educationpickerview{
            return educations.count
        }
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView == citypickerview{
            return cities[row]
        }
        else if pickerView == salraypickerview{
            return salaries[row]
        }
        else if pickerView == educationpickerview{
            return educations[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == citypickerview{
        city.text = cities[row]
        city.resignFirstResponder()
        }
        else if pickerView == salraypickerview{
        salary.text = salaries[row]
        salary.resignFirstResponder()
        }
        else if pickerView == educationpickerview{
        education.text = educations[row]
        education.resignFirstResponder()
        }
        
    }
    
    
}
