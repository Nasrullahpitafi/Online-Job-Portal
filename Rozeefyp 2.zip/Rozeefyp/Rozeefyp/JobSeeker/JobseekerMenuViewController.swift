//
//  JobseekerMenuViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 24/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class JobseekerMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "JobSeeker Menu"
        // Do any additional setup after loading the view.
    }
    

    @IBAction func profilePressed(_ sender: Any) {
        
        let controller:UserProfileViewController = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    @IBAction func matchedJobsPressed(_ sender: Any) {
        let controller:MatchedJobsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MatchedJobsViewController") as! MatchedJobsViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
    @IBAction func appliedjobPressed(_ sender: Any) {
            let controller:AppliedJobsViewController = self.storyboard?.instantiateViewController(withIdentifier: "AppliedJobsViewController") as! AppliedJobsViewController
            self.navigationController?.pushViewController(controller, animated: true)
        }
    
    @IBAction func alljobsPressed(_ sender: Any) {
        let controller:AllJobsViewController = self.storyboard?.instantiateViewController(withIdentifier: "AllJobsViewController") as! AllJobsViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
        
    }
    
    @IBAction func allcompaniesPressed(_ sender: Any) {
        
        let controller:AllCompaniesViewController = self.storyboard?.instantiateViewController(withIdentifier: "AllCompaniesViewController") as! AllCompaniesViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    @IBAction func favouritejobsPressed(_ sender: Any) {
        
        let controller:FavouriteJobsViewController = self.storyboard?.instantiateViewController(withIdentifier: "FavouriteJobsViewController") as! FavouriteJobsViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
}
