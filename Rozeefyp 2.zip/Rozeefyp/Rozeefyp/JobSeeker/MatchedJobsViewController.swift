//
//  AllJobsViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 13/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class MatchedJobsViewController: UIViewController {
    var mjm = MatchedJobsManager()
    var jobsdata : [MatchedJobs] = []
    var imagedata :String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Matched Jobs"
        jobsdata = mjm.matchedjobs(skill:Constant.user.first!.skills!)
        print (jobsdata.first?.jobtitle)
        print (Constant.user.first?.skills)
    
    }
    
}
extension MatchedJobsViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jobsdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "jobscell") as! AllJobsTableViewCell
        let jobs = jobsdata[indexPath.row]
        cell.jobtitle.text = jobs.jobtitle
        cell.cityLbl.text = jobs.city
        cell.companyLbl.text = jobs.companyname
        cell.lastdateLbl.text = jobs.lastdate?.components(separatedBy: "T").first ?? ""
        imagedata = jobs.image ?? ""
        if imagedata.count > 0 {
            cell.jobimage.image = convertBase64ToImage(imagedata)
        }
        
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller:JobDetailViewController = story.instantiateViewController(withIdentifier: "JobDetailViewController") as! JobDetailViewController
        let jobs = jobsdata[indexPath.row]
        //  controller.Careerlevel = jobs.careerlevel!
        controller.City = jobs.city!
        controller.Companyname = jobs.companyname!
        controller.Currentdate = jobs.currentdate!
        controller.Lastdate = jobs.lastdate!
        controller.Salary = jobs.salary!
        controller.Gender = jobs.gender!
        controller.Education = jobs.education!
        controller.Experience = jobs.experience!
        controller.Description = jobs.description!
        controller.Jobtype = jobs.jobtype!
        controller.Jobtitle = jobs.jobtitle!
        controller.Image = jobs.image!
        controller.Skill = jobs.skills!
        controller.companyid = jobs.companyid ?? 0
        controller.jobid = jobs.id
        
        
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
    
    
    
    
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return (decodedimage!)
    }
    
    
    
    
}

