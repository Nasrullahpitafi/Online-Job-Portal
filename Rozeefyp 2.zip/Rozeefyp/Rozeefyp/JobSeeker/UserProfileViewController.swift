//
//  UserProfileViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 29/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class UserProfileViewController: UIViewController,DataPass {

    
    @IBOutlet weak var adressLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var skillsLbl: UILabel!
    @IBOutlet weak var phoneLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    
    
    @IBOutlet weak var profileimage: UIImageView!
    var userimage :String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "User Profile"
        adressLbl.text = Constant.user.first?.address
        nameLbl.text = Constant.user.first?.username
        skillsLbl.text = Constant.user.first?.skills
        phoneLbl.text = Constant.user.first?.phoneno
        cityLbl.text = Constant.user.first?.city
        userimage = Constant.user.first?.image ?? ""
        if userimage.count > 0 {
            profileimage.image = convertBase64ToImage(userimage)
        }
        
    }
    
    @IBAction func editPressed(_ sender: Any) {
        
        let controller:EditProfieViewController = self.storyboard?.instantiateViewController(withIdentifier: "EditProfieViewController") as! EditProfieViewController
        controller.delegate = self
        
        self.navigationController?.pushViewController(controller, animated: true)
    }
    func DataPassing(name: String, address: String, city: String, Phoneno: String, Skills: String) {
        nameLbl.text = name
        adressLbl.text = address
        cityLbl.text = city
        phoneLbl.text = Phoneno
        skillsLbl.text = Skills
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return (decodedimage!)
    }
    

}
