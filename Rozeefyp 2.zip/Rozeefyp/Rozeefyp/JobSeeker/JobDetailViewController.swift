//
//  JobDetailViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 26/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class JobDetailViewController: UIViewController {

    @IBOutlet weak var jobimage: UIImageView!
    
    @IBOutlet weak var jobtitle: UILabel!
    
    @IBOutlet weak var city: UILabel!
    @IBOutlet weak var company: UILabel!
    
    @IBOutlet weak var currentdate: UILabel!
    
    @IBOutlet weak var lastdate: UILabel!
    
    @IBOutlet weak var jobtype: UILabel!
    
    @IBOutlet weak var experience: UILabel!
    
    @IBOutlet weak var education: UILabel!
    
    @IBOutlet weak var salary: UILabel!
    @IBOutlet weak var gender: UILabel!
    
    @IBOutlet weak var skills: UILabel!
    @IBOutlet weak var desc: UILabel!
    
    var Jobtitle : String = ""
    var Jobtype : String = ""
    var Salary : String = ""
    var Skill : String = ""
    var Careerlevel : String = ""
    var City : String = ""
    var Education : String = ""
    var Gender : String = ""
    var Currentdate : String = ""
    var Lastdate : String = ""
    var Description : String = ""
    var Companyname : String = ""
    var Experience : String = ""
    var Image : String = ""
    var companyid : Int = 0
    var jobid : Int = 0
    
    
    
    var adm = AppliedDataManager()
    var jobsdata : [AppliedData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Job Detail"
        jobsdata = adm.checkapply(jobseekerid: Constant.user.first?.id ?? 0, jobid: jobid)
        print(jobid)
        


        
        print (companyid) 
        jobtitle.text! = Jobtitle
        jobtype.text! = Jobtype
        salary.text! = Salary
        skills.text! = Skill
        city.text! = City
        education.text! = Education
        gender.text! = Gender
        currentdate.text! = Currentdate.components(separatedBy: "T").first ?? ""
        lastdate.text! = Lastdate.components(separatedBy: "T").first ?? ""
        desc.text! = Description
        company.text!  =  Companyname
        experience.text! = Experience
        
        
        
        if (Image.count ?? 0 > 0)
        {
            jobimage.image = convertBase64ToImage((Image ?? nil)!)
        }
        
        
    }
    

    @IBAction func applyPressed(_ sender: Any) {
        if jobsdata.count ?? 0 > 0{
            let alert = UIAlertController(title: "Attention", message: "You already applied for the job.Check applied jobs for status", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .destructive, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
        }
        else{
        var data = AppliedData()
        data.companyid = companyid
        data.jobid = jobid
        data.jobseekerid = Constant.user.first?.id ?? 0
        data.status = "Pending"
        let ad = AppliedDataManager()
        let ans = ad.postapplydata(newapply: data)
        if ans == true {
            let alert = UIAlertController(title: "Success", message: "You applied succesfully for the job !", preferredStyle: .alert)
            
            let okaction = UIAlertAction(title: "OK", style: .default) { (_) in
                
                self.navigationController?.popViewController(animated: true)
            }
            alert.addAction(okaction)
            self.present(alert, animated: true, completion: nil)
            
         }
        else{
            print(ad.Message)
        }
        }
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return decodedimage!
    }
    
    
    
    
}
