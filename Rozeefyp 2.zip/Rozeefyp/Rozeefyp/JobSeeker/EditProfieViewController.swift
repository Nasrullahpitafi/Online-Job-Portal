//
//  EditProfieViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 29/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit
protocol DataPass {
    func DataPassing(name:String,address:String,city:String,Phoneno:String,Skills:String)
}

class EditProfieViewController: UIViewController {

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var skillsField: UITextField!
    @IBOutlet weak var phonenoFiled: UITextField!
    @IBOutlet weak var cityFiled: UITextField!
    @IBOutlet weak var addressFiled: UITextField!
    var delegate : DataPass!
    var userimage : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Edit Profile"
        usernameField.text = Constant.user.first?.username
        skillsField.text = Constant.user.first?.skills
        phonenoFiled.text = Constant.user.first?.phoneno
        cityFiled.text = Constant.user.first?.city
        addressFiled.text = Constant.user.first?.address
        userimage = Constant.user.first?.image ?? ""
        if userimage.count > 0 {
            profileImage.image = convertBase64ToImage(userimage)
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func BrowsePressed(_ sender: Any) {
    }
    
    

    @IBAction func UpdatePressed(_ sender: Any) {
        let data = Signup()
        data.username = usernameField.text
        data.address = addressFiled.text
        data.city = cityFiled.text
        data.phoneno = phonenoFiled.text
        data.skills = skillsField.text
        data.image = Constant.user.first?.image
        data.email = Constant.user.first?.email
        data.id = Constant.user.first?.id ?? 0
        data.password = Constant.user.first?.password
        data.usertype = Constant.user.first?.usertype
        data.education = Constant.user.first?.education
        data.expectedsalary = Constant.user.first?.expectedsalary
        data.jobtitleinterested = "hkjh"
        
        print(Constant.user.first?.id ?? 0)
        let  sm = SignupManager()
        
        let ans = sm.updatestatus(newprofile: data)
            print ("Updated Succfully")
            print(sm.Message)
            
        
    
        
          delegate.DataPassing(name: usernameField.text!, address:addressFiled.text!, city: cityFiled.text!, Phoneno: phonenoFiled.text!,Skills: skillsField.text!  )
        
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return (decodedimage!)
    }
}
