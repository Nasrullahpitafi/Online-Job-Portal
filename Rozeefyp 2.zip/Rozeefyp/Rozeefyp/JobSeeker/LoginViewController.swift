//
//  LoginViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 14/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    
    
    @IBOutlet weak var passwordField: UITextField!
    
    var lm = SignupManager()
    var logindata : [Signup] = []

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func loginPressed(_ sender: Any) {
        if(self.usernameField.text! == "")
        {
            let alert = UIAlertController(title: "Try Again", message: "Enter Email", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(self.passwordField.text! == "")
        {
            let alert = UIAlertController(title: "Try Again", message: "Enter Password", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
       logindata = lm.login(email: usernameField.text!, password: passwordField.text!)
        Constant.user = logindata
        if logindata.first?.usertype == "Employer"
        {
         self.ShowEmployerMenu()
        }
        if logindata.first?.usertype == "Jobseeker"
        {
            self.ShowJobSeekerMenu()
                }
        if lm.Message.contains("fail"){
            let alert = UIAlertController(title: "Try Again", message: "Username or Password Incorrect", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        
    }
    
    @IBAction func createaccountPressed(_ sender: Any) {
        let actionSheet=UIAlertController(title: "Signup", message:"Create account as", preferredStyle:.actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Jobseeker", style:.default , handler:{action in self.ShowJobSeekerSignup()}))
        
        actionSheet.addAction(UIAlertAction(title: "Employer", style:.default , handler:{action in self.ShowEmployerSignup()}))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style:.destructive , handler:nil))
        
        present(actionSheet,animated: true)
        
        
    }
    func ShowEmployerMenu(){
        let controller:EmployerMenuViewController = self.storyboard?.instantiateViewController(withIdentifier: "EmployerMenuViewController") as! EmployerMenuViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    func ShowJobSeekerMenu(){
        let controller:JobseekerMenuViewController = self.storyboard?.instantiateViewController(withIdentifier: "JobseekerMenuViewController") as! JobseekerMenuViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    func ShowAllJobs(){
        let controller:AllJobsViewController = self.storyboard?.instantiateViewController(withIdentifier: "AllJobsViewController") as! AllJobsViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func ShowEmployerSignup(){
        let controller:EmployerSignupViewController = self.storyboard?.instantiateViewController(withIdentifier: "EmployerSignupViewController") as! EmployerSignupViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    func ShowJobSeekerSignup(){
        let controller:JobSeekerSignupViewController = self.storyboard?.instantiateViewController(withIdentifier: "JobSeekerSignupViewController") as! JobSeekerSignupViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    

}
