//
//  AllCompaniesViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 01/07/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AllCompaniesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    var fj = FavouriteJobsManager()
    var jobsdata : [FavouriteJobs] = []
    var imagedata :String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "All Companies"
        jobsdata = fj.allcompanies()
        print (jobsdata.first?.username)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return   jobsdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "allcompaniescell") as! AllCompaniesTableViewCell
        let data = jobsdata[indexPath.row]
        cell.companynameLabel.text = data.username
        cell.cityLabel.text = data.city
        cell.phonenoLabel.text = data.phoneno
        imagedata = data.image ?? ""
        if imagedata.count > 0 {
            cell.companyImage.image = convertBase64ToImage(imagedata)
        }
        cell.addtoFavourite.tag = indexPath.row
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    
    @IBAction func addtofavouritePressed(_ sender: UIButton) {

        let dataa = FavouriteJobs()
        dataa.companyid = jobsdata.first?.id
        dataa.jobseekerid = Constant.user.first?.id
        let fjm = FavouriteJobsManager()
        let ans = fjm.favouritedata(newdata: dataa)
        if ans == true{
            print("Success")
        print(fjm.Message)
        }
        
        
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
        let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        return (decodedimage!)
    }

}

