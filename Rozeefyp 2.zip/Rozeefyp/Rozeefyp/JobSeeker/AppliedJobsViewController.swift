//
//  AppliedJobsViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 03/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AppliedJobsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
    
    var ajm = AppliedJobsManager()
    var jobsdata : [AppliedJobs] = []
    var myjobid : Int = 0
    var statusid : Int = 0
    var myemployerid : Int = 0
    var myjobseekerid : Int = 0
    var mystatus : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "AppliedJobs"
        jobsdata = ajm.appliedjobs(jobseeker: Constant.user.first?.id ?? 0)
        print (jobsdata.first?.companyid)

    }
    
    @IBAction func QuizAttemptPressed(_ sender: UIButton) {
        myjobid = jobsdata[sender.tag].jobid
        statusid = jobsdata[sender.tag].id
        myemployerid = jobsdata[sender.tag].companyid
        mystatus = jobsdata[sender.tag].status
        
        
        let controller:AttemptQuizViewController = self.storyboard?.instantiateViewController(withIdentifier: "AttemptQuizViewController") as! AttemptQuizViewController
        self.navigationController?.pushViewController(controller, animated: true)
        
        controller.jobid = self.myjobid
        controller.mystatusid = self.statusid
        controller.employerid = self.myemployerid
        controller.status = self.mystatus
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return jobsdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "appliedjobscell") as! AppliedJobsTableViewCell
        let data  = jobsdata[indexPath.row]
        cell.jobtitleLbl.text! = data.jobtitle!
        cell.companameLbl.text! = data.companyname!
        cell.statusLbl.text! = data.status!
        cell.cityLbl.text! = data.city!
       cell.attempQuiz.tag = indexPath.row
       if data.status == "Shortlisted"
        {
            cell.attempQuiz.isHidden = false
        }
       else{
            cell.attempQuiz.isHidden = true
       }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 190
    }
}
