//
//  AttemptQuizViewController.swift
//  Rozeefyp
//
//  Created by Asjd on 12/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AttemptQuizViewController: UIViewController {

    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var timerLabel: UILabel!
    
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var optionB: UIButton!
    
    @IBOutlet weak var optionD: UIButton!
    @IBOutlet weak var optionC: UIButton!
    
    var jobid : Int = 0
    var mystatusid : Int = 0
    var employerid : Int = 0
    var jobseekerid : Int = 0
    var status : String = ""
    
    
    
    var qm = QuizManager()
    var data : [Quiz] = []
    
    
    var selectedAnswer : String?
    var timer: Timer?
    var timerCount = 20
    var questionnumber :Int = 0
    var score :Int = 0

    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Attempt Quiz"
        
        timerLabel.text = "\(timerCount) seconds"
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.fireTimer), userInfo: nil, repeats: true)
        
        self.addquestion()
        
        
        
        data = qm.getquiz(jobid:jobid)
      
        print("statusid\(mystatusid)")
      //  print("jobseekerid\(Constant.user.first!.id)")
        print("employerid\(employerid)")
        print("statusid\(status)")


        
    }
    @objc func fireTimer() {
        print("Timer fired!")
        timerCount = 1
        timerLabel.text = "\(timerCount) seconds"
        if timerCount == 0 {
            timerCount = 20
            self.optionC.backgroundColor = UIColor.darkGray
            self.optionA.backgroundColor = UIColor.darkGray
            self.optionB.backgroundColor = UIColor.darkGray
            self.optionD.backgroundColor = UIColor.darkGray
            if selectedAnswer == data[questionnumber].answer
            {
                
                score += 1
                print ("correct \(score)")
                
                print(score)
            }
            else{
                print ("wrong")
            }
            selectedAnswer = ""
            questionnumber = questionnumber + 1
            addquestion()
        }
    }
    func addquestion(){
        if questionnumber < ((data.count) ){
            optionA.tag = 0
            optionB.tag = 1
            optionC.tag = 2
            optionD.tag = 3
            
            optionA.setTitle(data[questionnumber].optiona, for: UIControl.State.normal)
            optionB.setTitle(data[questionnumber].optionb, for: UIControl.State.normal)
            optionC.setTitle(data[questionnumber].optionc, for: UIControl.State.normal)
            optionD.setTitle(data[questionnumber].optiond, for: UIControl.State.normal)
            
            questionLabel.text = data[questionnumber].question
            selectedAnswer = data[questionnumber].answer
        }
        else{
            timer?.invalidate()
            let alert = UIAlertController(title: "Congrats", message: "Quiz is ended!", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Exit", style: .default, handler: {action in self.exit()})
            alert.addAction(restartAction)
            present(alert,animated: true,completion: nil)
            
        }
        
    }
    func exit(){
        var dataa : [AppliersData] = []
        let ajm = AppliersDataManager()
        dataa = ajm.searchById(id: mystatusid)
        var adata = AppliersData()
        print(dataa[0].jobid)
        adata.id = mystatusid
        adata.jobid = dataa[0].jobid
        adata.jobseekerid = dataa[0].jobseekerid
        adata.companyid =  dataa[0].companyid
        adata.quizscore = "\(score)/\(data.count-1 ?? 0)"
        //data.id = statusid
        
        adata.status = status
        
        let ans = ajm.updatestatus(newstatus: adata)
        print("Updated")
        
        print(ajm.Message)
        
        
        
        
    }
    
    
    
    @IBAction func nextPressed(_ sender: Any) {
        timerCount = 20
        timer?.invalidate()
        timerLabel.text = "\(timerCount) seconds"
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.fireTimer), userInfo: nil, repeats: true)
        self.optionC.backgroundColor = UIColor.darkGray
        self.optionA.backgroundColor = UIColor.darkGray
        self.optionB.backgroundColor = UIColor.darkGray
        self.optionD.backgroundColor = UIColor.darkGray
        if selectedAnswer == data[questionnumber].answer
        {
            
            score += 1
            print ("correct \(score)")
        }
        else{
            print ("wrong")
        }
        selectedAnswer = ""
        questionnumber = questionnumber + 1
        addquestion()
        
        print(score)
    }
    
    @IBAction func optionApressed(_ sender: Any) {
        
        optionA.isSelected = true
        optionB.isSelected = false
        optionC.isSelected = false
        optionD.isSelected = false
        self.optionA.backgroundColor = UIColor.green
        self.optionB.backgroundColor = UIColor.darkGray
        self.optionC.backgroundColor = UIColor.darkGray
        self.optionD.backgroundColor = UIColor.darkGray
        selectedAnswer = "A"
    }
    
    
    @IBAction func optionBpressed(_ sender: Any) {
        optionB.isSelected = true
        optionA.isSelected = false
        optionC.isSelected = false
        optionD.isSelected = false
        
        self.optionB.backgroundColor = UIColor.green
        self.optionA.backgroundColor = UIColor.darkGray
        self.optionC.backgroundColor = UIColor.darkGray
        self.optionD.backgroundColor = UIColor.darkGray
        selectedAnswer = "B"
    }
    
    @IBAction func optionCpressed(_ sender: Any) {
        optionB.isSelected =  false
        optionA.isSelected = false
        optionC.isSelected = true
        optionD.isSelected = false
        
        self.optionC.backgroundColor = UIColor.green
        self.optionA.backgroundColor = UIColor.darkGray
        self.optionB.backgroundColor = UIColor.darkGray
        self.optionD.backgroundColor = UIColor.darkGray
        selectedAnswer = "C"
        
    }
    
    
    @IBAction func optionDpressed(_ sender: Any) {
        optionB.isSelected = false
        optionA.isSelected = false
        optionC.isSelected = false
        optionD.isSelected = true
        
        
        self.optionD.backgroundColor = UIColor.green
        self.optionA.backgroundColor = UIColor.darkGray
        self.optionC.backgroundColor = UIColor.darkGray
        self.optionB.backgroundColor = UIColor.darkGray
        selectedAnswer = "D"
    }
    

}
