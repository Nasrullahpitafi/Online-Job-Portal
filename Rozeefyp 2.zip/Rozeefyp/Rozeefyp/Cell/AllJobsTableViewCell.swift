//
//  AllJobsTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 13/04/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AllJobsTableViewCell: UITableViewCell {

    @IBOutlet weak var jobtitle: UILabel!
    
    @IBOutlet weak var companyLbl: UILabel!
    
    @IBOutlet weak var cityLbl: UILabel!
    
    @IBOutlet weak var jobimage: UIImageView!
    @IBOutlet weak var lastdateLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
