//
//  AppliedJobsTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 03/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AppliedJobsTableViewCell: UITableViewCell {

    @IBOutlet weak var jobtitleLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var companameLbl: UILabel!
    
    @IBOutlet weak var attempQuiz: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
