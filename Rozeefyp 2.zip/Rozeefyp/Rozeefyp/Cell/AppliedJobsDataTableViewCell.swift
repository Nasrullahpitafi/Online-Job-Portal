//
//  AppliedJobsDataTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 03/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AppliedJobsDataTableViewCell: UITableViewCell {

    @IBOutlet weak var jobtitleLbl: UILabel!
    
    @IBOutlet weak var companyLbl: UILabel!
    
    
    @IBOutlet weak var lastdateLbl: UILabel!
    
    @IBOutlet weak var statusLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
