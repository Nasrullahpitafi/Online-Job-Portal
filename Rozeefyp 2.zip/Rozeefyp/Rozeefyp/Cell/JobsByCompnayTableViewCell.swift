//
//  JobsByCompnayTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 01/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class JobsByCompnayTableViewCell: UITableViewCell {

    @IBOutlet weak var jobtitleLbl: UILabel!
    
    @IBOutlet weak var lastdateLbl: UILabel!
    
    @IBOutlet weak var descLbl: UILabel!
    
    
    @IBOutlet weak var ViewQuiz: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
