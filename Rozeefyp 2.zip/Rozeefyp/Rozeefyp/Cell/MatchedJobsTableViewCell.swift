//
//  MatchedJobsTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 17/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class MatchedJobsTableViewCell: UITableViewCell {

    @IBOutlet weak var jobtitleLabel: UILabel!
    
    @IBOutlet weak var skillsLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
