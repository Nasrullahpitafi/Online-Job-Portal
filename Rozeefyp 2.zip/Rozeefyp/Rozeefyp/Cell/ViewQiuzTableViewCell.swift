//
//  ViewQiuzTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 01/06/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class ViewQiuzTableViewCell: UITableViewCell {

    
    @IBOutlet weak var questionLbl: UILabel!
    
    @IBOutlet weak var optionALbl: UILabel!
    @IBOutlet weak var optionDLbl: UILabel!
    @IBOutlet weak var optionCLbl: UILabel!
    @IBOutlet weak var optionBLbl: UILabel!
    
    
    @IBOutlet weak var answerLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
