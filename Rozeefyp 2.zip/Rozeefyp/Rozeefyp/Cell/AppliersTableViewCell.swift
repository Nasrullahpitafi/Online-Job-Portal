//
//  AppliersTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 04/05/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AppliersTableViewCell: UITableViewCell,UIPickerViewDelegate,UIPickerViewDataSource {
    

    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var jobtitleLabel: UILabel!
    
    @IBOutlet weak var statusField: UITextField!
    
    
    @IBOutlet weak var quizscore: UILabel!
    var status =  ["Shortlisted","Interviewing","Rejected","Accepted"]

    var statusPickerview = UIPickerView()
    var statusid : Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        statusField.inputView = statusPickerview
        
        statusField.placeholder = "Select Status"
        
        
        statusPickerview.delegate = self
        statusPickerview.dataSource = self
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return status.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return status[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        var dataa : [AppliersData] = []
        let ajm = AppliersDataManager()
        dataa = ajm.searchById(id: statusid)
        var data = AppliersData()
        print("heloo\(statusid)")
        print(dataa[0].jobid)
        data.id = statusid
        data.jobid = dataa[0].jobid
        data.jobseekerid = dataa[0].jobseekerid
        data.companyid =  dataa[0].companyid
        data.quizscore = dataa[0].quizscore
        statusField.text = status[row]
        statusField.resignFirstResponder()

        //data.id = statusid
        
        data.status = statusField.text!
        
        let ans = ajm.updatestatus(newstatus: data)
        print("Updated")
    
            print(ajm.Message)
        
    }
    
    

}
