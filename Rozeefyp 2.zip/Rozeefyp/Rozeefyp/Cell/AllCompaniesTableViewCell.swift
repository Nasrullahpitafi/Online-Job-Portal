//
//  AllCompaniesTableViewCell.swift
//  Rozeefyp
//
//  Created by Asjd on 01/07/2021.
//  Copyright © 2021 Asjd. All rights reserved.
//

import UIKit

class AllCompaniesTableViewCell: UITableViewCell {

    
    @IBOutlet weak var addtoFavourite: UIButton!
    @IBOutlet weak var companynameLabel: UILabel!
    @IBOutlet weak var companyImage: UIImageView!
    @IBOutlet weak var phonenoLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
